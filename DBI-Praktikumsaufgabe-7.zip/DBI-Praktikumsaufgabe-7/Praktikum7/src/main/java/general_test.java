public class general_test {
    public static void main(String[] args) {
        int c =(int) (Math.random() * 2+ 1);
        System.out.println(c);
    }
}
